var ApiKeyChecker = (function () {
    function ApiKeyChecker() {
    }
    return ApiKeyChecker;
}());
