function parse(form) {
    var dictionary = {};
    var text_temp = form.val();
    if (!text_temp)
        return;
    if (!text_temp.match(/[:,]/))
        return;
    text_temp = text_temp.trim();
    var textarr = text_temp.split('\n');
    for (var _i = 0, textarr_1 = textarr; _i < textarr_1.length; _i++) {
        var elem = textarr_1[_i];
        var i = elem.split(':');
        var id = i[0];
        if (!parseInt(id))
            return;
        var words = i[1].split(',');
        for (var _a = 0, words_1 = words; _a < words_1.length; _a++) {
            var word = words_1[_a];
            word = word.trim();
            var spacedWordsInArr = word.split(' ');
            dictionary[spacedWordsInArr[0]] = [word, spacedWordsInArr.length, parseInt(id)];
        }
    }
    return dictionary;
}
function parseBlackList(form) {
    var text_temp = form.val();
    if (!text_temp)
        return;
    text_temp = text_temp.trim();
    var textarr = text_temp.split(',');
    return textarr;
}
function loadTextbox(key, textbox) {
    chrome
        .storage
        .sync
        .get(key, function (item) {
        console.log(item);
        if (item.hasOwnProperty(key)) {
            var rawText = item[key];
            textbox.val(function (index, val) { return val + rawText; });
        }
    });
}
function saveToChromeMemory(key, obj) {
    console.log(obj);
    var setter = {};
    setter[key] = obj;
    chrome
        .storage
        .local
        .set(setter, function () { console.log("NOICE"); });
}
function saveRawText(key, optionsRaw) {
    var obj = {};
    obj[key] = optionsRaw;
    chrome
        .storage
        .sync
        .set(obj);
}
function loadCheckboxState(checkbox) {
    chrome.storage.local.get("standartHelpers", function (item) {
        console.log(item);
        if (item.standartHelpers)
            checkbox.prop("checked", true);
        else
            checkbox.prop("checked", false);
    });
}
$(document).ready(function () {
    var checkbox = $("#standartHelpers");
    var userHelperstextbox = $('#text');
    var blacklistTextbox = $('#blacklist');
    var saveButton = $('#mainbutton');
    loadTextbox('optionsRaw', userHelperstextbox);
    loadTextbox('blacklistRaw', blacklistTextbox);
    loadCheckboxState(checkbox);
    saveButton.click(function () {
        var parsedObject = parse(userHelperstextbox);
        var blacklistArray = parseBlackList(blacklistTextbox);
        saveRawText('blacklistRaw', blacklistTextbox.val());
        saveRawText('optionsRaw', userHelperstextbox.val());
        saveToChromeMemory('userDict', parsedObject);
        saveToChromeMemory('blacklist', blacklistArray);
    });
    checkbox.click(function () {
        if (this.checked)
            saveToChromeMemory('standartHelpers', true);
        else
            saveToChromeMemory('standartHelpers', false);
    });
    var location = window.location.href;
    if (location.indexOf('?') > -1) {
        console.log(location);
        location = location.substr(location.indexOf('?') + 1);
        var stickerId = parseInt(location);
        if (stickerId) {
            userHelperstextbox.val(function (index, value) {
                console.log(index);
                return value + stickerId + ':\n';
            });
        }
        else
            alert('Выбран не стикер');
    }
});
