var Parser = (function () {
    function Parser() {
        this.dictionary = {};
        this.rawText = '';
    }
    Parser.prototype.parseForm = function (form) {
        var text_temp = form.val();
        this.rawText = text_temp;
        if (!text_temp)
            return;
        if (!text_temp.match(/[:,]/))
            return;
        text_temp = text_temp.trim();
        var textarr = text_temp.split('\n');
        for (var _i = 0, textarr_1 = textarr; _i < textarr_1.length; _i++) {
            var elem = textarr_1[_i];
            var i = elem.split(':');
            var id = i[0];
            if (!parseInt(id))
                return;
            var words = i[1].split(',');
            for (var _a = 0, words_1 = words; _a < words_1.length; _a++) {
                var word = words_1[_a];
                word = word.trim();
                var spacedWordsInArr = word.split(' ');
                this.dictionary[spacedWordsInArr[0]] = [word, spacedWordsInArr.length, parseInt(id)];
            }
        }
    };
    return Parser;
}());
function loadFromChromeMemory(form) {
    chrome
        .storage
        .local
        .get('optionsRaw', function (item) {
        console.log(item);
        if (item.hasOwnProperty('optionsRaw')) {
            var rawText = item['optionsRaw'];
            form.val(rawText);
        }
    });
}
function saveToChromeMemory(userDict) {
    console.log(userDict);
    chrome
        .storage
        .local
        .set({ 'userDict': userDict });
}
$(document).ready(function () {
    var form = $('#text');
    loadFromChromeMemory(form);
    var saveButton = $('#mainbutton');
    saveButton.click(function () {
        var parser = new Parser();
        parser.parseForm(form);
        saveToChromeMemory(parser.dictionary);
    });
});
