var newTabId;
var token;
chrome
    .runtime
    .onMessage
    .addListener(function (request, sender, sendResponse) {
    console.log(request);
    if (request.getAccessTokenURL) {
        chrome
            .tabs
            .create({
            url: request.getAccessTokenURL,
            selected: true
        }, function (tab) {
            var newTabId = tab.id;
            chrome
                .tabs
                .onUpdated
                .addListener(function (tabId, changeInfo) {
                if (tabId == newTabId && changeInfo.url != undefined && changeInfo.status == "loading") {
                    if (changeInfo.url.indexOf('oath.vk.com/blank.html')) {
                        var firstBorder = changeInfo
                            .url
                            .indexOf('=') + 1;
                        var secondBorder = changeInfo
                            .url
                            .indexOf('&');
                        token = changeInfo
                            .url
                            .substring(firstBorder, secondBorder);
                        chrome
                            .storage
                            .local
                            .set({
                            'vk_token': token
                        }, function () {
                            chrome
                                .runtime
                                .sendMessage("apikeySet");
                        });
                        //sendResponse({Success: token})
                        chrome
                            .tabs
                            .remove(newTabId);
                    }
                }
            });
        });
    }
});
