QUnit.test('isApiKeyInStorage', function (assert) { });
