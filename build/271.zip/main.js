var buttonsContainer;
var HelpersUtil = (function () {
    function HelpersUtil() {
    }
    HelpersUtil.getRandomInt = function (min, max) {
        if (min === max)
            return min;
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };
    return HelpersUtil;
}());
var ls = {
    checkVersion: function () {
        return (window.localStorage !== undefined);
    },
    set: function (k, v) {
        this.remove(k);
        try {
            return (ls.checkVersion())
                ? localStorage.setItem(k, JSON.stringify(v))
                : false;
        }
        catch (e) {
            return false;
        }
    },
    get: function (k) {
        if (!ls.checkVersion()) {
            return false;
        }
        try {
            return JSON.parse(localStorage.getItem(k));
        }
        catch (e) {
            return false;
        }
        ;
    },
    remove: function (k) {
        try {
            localStorage.removeItem(k);
        }
        catch (e) { }
        ;
    }
};
function getVkRequestUrl() {
    var url = "https://oauth.vk.com/authorize?";
    var data = {
        client_id: "5792521",
        v: '5.52',
        redirect_uri: "https://oauth.vk.com/blank.html",
        scope: "messages,docs,photos,offline",
        response_type: "token"
    };
    return url + $.param(data);
}
function getApiKey(onFail, button) {
    chrome
        .storage
        .local
        .get('vk_token', function (token) {
        var vk_token = token['vk_token'];
        if (vk_token) {
            if (button)
                button.remove();
            addListeners(vk_token);
        }
        else
            onFail();
    });
}
function addListeners(apiKey) {
    chrome
        .storage
        .local
        .get('userDict', function (dict) {
        var keywords = new KeywordsGetter(dict['userDict']).getHelpersDictionary();
        var searcher = new Searcher(keywords);
        var sender = new Sender(apiKey);
        var eventListener = new EventListenersSetter(searcher, sender);
        eventListener.setListeners();
    });
}
function addApiKeyButton() {
    var button = $('<a class="helperelement">Get api key<a>');
    button.on('click', function () {
        this.innerText = 'close';
        getApiKey(getApiKeyFromServer, this);
    });
    buttonsContainer.append(button);
}
function getApiKeyFromServer() {
    var requestURL = getVkRequestUrl();
    chrome
        .runtime
        .sendMessage({ getAccessTokenURL: requestURL });
}
var KeywordsGetter = (function () {
    function KeywordsGetter(userKeywords) {
        this.keywordsJson = ls.get("stickers_keywords");
        this.userKeywords = userKeywords;
    }
    KeywordsGetter.prototype.getHelpersDictionary = function () {
        var dict = {};
        for (var x = 0; x < this.keywordsJson['keywords'].length; x++)
            for (var i = 0; i < this.keywordsJson['keywords'][x]['words'].length; i++)
                if (!this.keywordsJson['keywords'][x]['words'][i].includes('&')) {
                    var Helper = this.keywordsJson['keywords'][x]['words'][i];
                    var stickerIDsArray = this.keywordsJson['keywords'][x]['user_stickers'];
                    var arrayOfHelper = Helper.split(' ');
                    if (stickerIDsArray.length !== 0)
                        dict[arrayOfHelper[0]] = [
                            Helper,
                            arrayOfHelper.length,
                            stickerIDsArray[HelpersUtil.getRandomInt(0, stickerIDsArray.length - 1)]
                        ];
                }
        var userDict = this.userKeywords;
        Object.assign(dict, userDict);
        return dict;
    };
    return KeywordsGetter;
}());
var Searcher = (function () {
    function Searcher(keywords) {
        this.dictionary = keywords;
    }
    Searcher.prototype.search = function (wordsArray) {
        var matched = [];
        for (var position in wordsArray) {
            if (this.dictionaryHas(wordsArray, position)) {
                var fullKeyword = this.dictionary[wordsArray[position]][0];
                var stickerID = this.dictionary[wordsArray[position]][2];
                matched.push([fullKeyword, stickerID]);
            }
        }
        return matched;
    };
    Searcher.prototype.dictionaryHas = function (array, position) {
        var word = array[position];
        if (this.isPartlyInDictionary(word) && this.isCompletelyInDictionary(array, position))
            return true;
        return false;
    };
    Searcher.prototype.isPartlyInDictionary = function (word) {
        return this
            .dictionary
            .hasOwnProperty(word);
    };
    Searcher.prototype.isCompletelyInDictionary = function (arr, wordPos) {
        var stringWithSameWordAmount = this.expandString(arr, wordPos, this.dictionary[arr[wordPos]][1]);
        var keyword = this.dictionary[arr[wordPos]][0];
        if (keyword === stringWithSameWordAmount)
            return true;
        return false;
    };
    Searcher.prototype.expandString = function (arr, position, expansionLength) {
        var upperBoundary = parseInt(position) + parseInt(expansionLength);
        var lowerBoundary = position;
        return arr
            .slice(lowerBoundary, upperBoundary)
            .join(' ');
    };
    return Searcher;
}());
var Sender = (function () {
    function Sender(apiKey) {
        this.basic_url = "https://api.vk.com/method/";
        this.apiKey = apiKey;
    }
    Sender.prototype.sendSticker = function (sticker_id) {
        $.ajax({
            url: this.getUrlForApiMethod("messages.send"),
            data: {
                v: 5.62,
                peer_id: this.currentChatId,
                access_token: this.apiKey,
                sticker_id: sticker_id
            },
            complete: function (httpObject) { }
        });
    };
    Sender.prototype.getUrlForApiMethod = function (method) {
        return this.basic_url + method + "?";
    };
    Object.defineProperty(Sender.prototype, "currentChatId", {
        get: function () {
            return window
                .location
                .href
                .substr(window.location.href.indexOf('sel=') + 4);
        },
        enumerable: true,
        configurable: true
    });
    return Sender;
}());
var EventListenersSetter = (function () {
    function EventListenersSetter(searcher, sender) {
        this.inputBox = $('.im_editable');
        this.buttons = [];
        this.sender = sender; //new Sender(apiKey)
        this.searcher = searcher;
    }
    EventListenersSetter.prototype.setListeners = function () {
        this.setInputListener();
        this.setKeyUpListener();
    };
    EventListenersSetter.prototype.setInputListener = function () {
        var _this = this;
        this
            .inputBox
            .on('input', function () {
            _this.clearButtons();
            var keywordAndId = _this
                .searcher
                .search(_this.wordsArray);
            for (var _i = 0, keywordAndId_1 = keywordAndId; _i < keywordAndId_1.length; _i++) {
                var tuple = keywordAndId_1[_i];
                _this.addButton(tuple);
            }
        });
    };
    Object.defineProperty(EventListenersSetter.prototype, "wordsArray", {
        get: function () {
            return this
                .inputBox
                .text()
                .trim()
                .split(' ');
        },
        enumerable: true,
        configurable: true
    });
    EventListenersSetter.prototype.setKeyUpListener = function () {
        var _this = this;
        this
            .inputBox
            .on('keyup', function (e) {
            if (e.which === 8) {
                // TAB
                _this.clearButtons();
            }
            if (e.which === 13 && _this.buttons.length) {
                // ENTER
                _this
                    .sender
                    .sendSticker(_this.firstSticker);
                _this.clearButtons();
            }
        });
    };
    Object.defineProperty(EventListenersSetter.prototype, "firstSticker", {
        get: function () {
            return this
                .buttons[0]
                .data('id');
        },
        enumerable: true,
        configurable: true
    });
    EventListenersSetter.prototype.addButton = function (keywordAndId) {
        var keyword = keywordAndId[0];
        var button = $("<a class='helperelement'>" + keyword + "<a>");
        button.data('id', keywordAndId[1]);
        this
            .buttons
            .push(button);
        buttonsContainer.append(button);
    };
    EventListenersSetter.prototype.clearButtons = function () {
        this.buttons = [];
        buttonsContainer.empty();
    };
    return EventListenersSetter;
}());
$(document)
    .ready(function () {
    buttonsContainer = $('<div class="helper"></div>');
    $('.im-chat-input--textarea').prepend(buttonsContainer);
    getApiKey(addApiKeyButton);
});
